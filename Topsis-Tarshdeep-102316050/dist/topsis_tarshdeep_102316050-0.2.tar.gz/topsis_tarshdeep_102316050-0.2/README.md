# Topsis-Tarshdeep-102316050

This Python package implements TOPSIS (Technique for Order of Preference by Similarity to Ideal Solution) for multi-criteria decision making.

## Installation
```bash
pip install Topsis-Tarshdeep-102316050
